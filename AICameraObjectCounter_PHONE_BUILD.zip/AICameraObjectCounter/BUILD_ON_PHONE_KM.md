# Build APK ដោយប្រើទូរស័ព្ទ Android ប៉ុណ្ណោះ

ឯកសារនេះប្រើ GitHub Actions ជា cloud build ដូច្នេះមិនចាំបាច់មានកុំព្យូទ័រ។ ត្រូវមានគណនី GitHub និងអ៊ីនធឺណិត។

1. បើក https://github.com ក្នុង Chrome ហើយ Sign in ឬបង្កើតគណនី។
2. ចុច `+` → `New repository`។ ដាក់ឈ្មោះ `AICameraObjectCounter` ហើយជ្រើស `Private` ឬ `Public`។ ចុច `Create repository`។
3. Extract ZIP នេះដោយប្រើ ZArchiver។ ចូលទៅក្នុង folder `AICameraObjectCounter`។
4. ក្នុង repository នៅ GitHub ចុច `Add file` → `Upload files`។ ជ្រើសឯកសារ/ថតទាំងអស់នៅខាងក្នុង folder `AICameraObjectCounter` (រួមទាំង `.github` និង `gradlew`)។ កុំ upload folder មួយទៀតជាន់ពីលើ ប្រសិនបើវាធ្វើឱ្យ `build.gradle.kts` មិននៅ root។ ចុច `Commit changes`។
5. បើក tab `Actions` → workflow `Build Android APK` → `Run workflow` → `Run workflow`។ ការបញ្ចូល source ទៅ branch `main` ក៏ចាប់ផ្តើម build ដោយស្វ័យប្រវត្តិដែរ។
6. រង់ចាំឱ្យ workflow មានសញ្ញាពណ៌បៃតង។ បើក run នោះ ហើយនៅផ្នែក `Artifacts` ចុច `AICameraObjectCounter-debug-apk` ដើម្បីទាញយក ZIP ដែលមាន APK។
7. Extract ZIP artifact ដែលទាញយក រួចចុច `app-debug.apk` ដំឡើង។ Android អាចស្នើឱ្យអនុញ្ញាត `Install unknown apps` សម្រាប់ Chrome/Files; អនុញ្ញាតតែឯកសារដែលអ្នកទុកចិត្ត។

## បញ្ហាដែលត្រូវដឹង
- Workflow ដំណើរការ `downloadModel` មុន build ព្រោះ source ZIP មិនមាន model `.tflite`។
- ប្រសិនបើ `downloadModel` បរាជ័យ សូមមើល log នៃ step នោះ; មិនត្រូវបង្កើត model ទទេ ឬប្ដូរឈ្មោះ HTML error page ទៅ `.tflite` ទេ។
- Project នេះមិនទាន់ត្រូវបាន compile/test ដោយអ្នកបង្កើតដើមទេ។ បើ build បរាជ័យ សូមចូល workflow run → step ដែលមានសញ្ញាក្រហម → Copy error log ហើយប្រើវាដើម្បីកែ source។
- APK `debug` គឺសម្រាប់ដំឡើងសាកល្បង មិនមែន signed release APK សម្រាប់ចែកចាយជាផ្លូវការទេ។
