# Model setup

## Why the model is not bundled
The model could not be downloaded in the environment where this project was generated (outbound access to Google
storage and GitHub was blocked), and **a placeholder or fake file would be worse than none**, so nothing was added.
EfficientDet-Lite is published by Google under the Apache License 2.0 (redistribution is permitted), so you may bundle it
in your own build once you have downloaded it.

## What the app needs
A TensorFlow Lite **object-detection model with metadata** (labels + normalisation embedded), in the format the TFLite
Task Library reads. The app looks for these file names in `app/src/main/assets/`, first match wins:

1. `efficientdet_lite0.tflite`  (recommended: smallest/fastest, ~4.4 MB, input 320×320)
2. `efficientdet_lite1.tflite`
3. `efficientdet_lite2.tflite`
4. `model.tflite`

## Option A – Gradle helper (easiest)
```
./gradlew downloadModel
```
It downloads from the TensorFlow Task Library sample location:
`https://storage.googleapis.com/download.tensorflow.org/models/tflite/task_library/object_detection/android/lite-model_efficientdet_lite0_detection_metadata_1.tflite`
and refuses to save anything smaller than ~100 KB (so an HTML error page can never be mistaken for a model).
**This URL is recalled from memory of the official TensorFlow examples and was not verified from here.** If the task fails, use Option B.

## Option B – manual download
1. Open the EfficientDet-Lite0 (detection, with metadata) page on Kaggle Models / TensorFlow Hub:
   search "EfficientDet-Lite0 detection metadata" at <https://www.kaggle.com/models> (publisher: tensorflow).
   The TFLite variant named `lite0/detection/metadata/1` (the *metadata* variant) is the right one.
2. Download the `.tflite` file and rename it to `efficientdet_lite0.tflite`.
3. Copy it to `app/src/main/assets/efficientdet_lite0.tflite` and rebuild.

## Verify it
* File size should be roughly 4–5 MB (Lite0). A few hundred bytes means you saved an error page.
* Run the app: the status chip changes from "Loading AI model…" to "AI running". Settings ▸ "About the AI model" shows the file in use.

## Supported categories (COCO, 80 classes)
person, bicycle, car, motorcycle, airplane, bus, train, truck, boat, traffic light, fire hydrant, stop sign, parking meter,
bench, bird, cat, dog, horse, sheep, cow, elephant, bear, zebra, giraffe, backpack, umbrella, handbag, tie, suitcase,
frisbee, skis, snowboard, sports ball, kite, baseball bat, baseball glove, skateboard, surfboard, tennis racket, bottle,
wine glass, cup, fork, knife, spoon, bowl, banana, apple, sandwich, orange, broccoli, carrot, hot dog, pizza, donut, cake,
chair, couch, potted plant, bed, dining table, toilet, tv, laptop, mouse, remote, keyboard, cell phone, microwave, oven,
toaster, sink, refrigerator, book, clock, vase, scissors, teddy bear, hair drier, toothbrush.

The app does **not** recognise every object in the world – only these classes.

## Using a different model
Any TFLite detection model with Task-Library metadata works if you name it as above. Models without metadata (labels/normalisation)
fail to load, and the app shows that message instead of crashing.
