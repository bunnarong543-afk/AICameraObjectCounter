# Third-party components

This list is from the author's knowledge, not from an automated license scan. Check each project's current terms before distributing.

| Component | Use | License |
|---|---|---|
| AndroidX (core-ktx, appcompat, recyclerview) | UI/platform | Apache License 2.0 |
| AndroidX CameraX 1.3.4 | Camera preview + analysis | Apache License 2.0 |
| Material Components for Android 1.12.0 | UI widgets | Apache License 2.0 |
| TensorFlow Lite Task Library (task-vision 0.4.4) and its dependencies (TFLite runtime, support library) | On-device inference | Apache License 2.0 |
| Kotlin standard library | Language runtime | Apache License 2.0 |
| JUnit 4 (tests only) | Unit tests | Eclipse Public License 1.0 |
| EfficientDet-Lite model (**not bundled** – you download it) | Object detection | Apache License 2.0 (Google / TensorFlow Model Garden). Trained on COCO 2017, whose annotations are CC BY 4.0 |

Apache License 2.0 text: <https://www.apache.org/licenses/LICENSE-2.0>

If you ship the model inside your app, include the Apache 2.0 notice and attribution to the TensorFlow authors.

The app's own source code and icons were generated for the project owner; license them as you choose.
