# Build instructions

## Requirements
* Android Studio Koala (2024.1) or newer, using its bundled JDK 17
* Android SDK Platform 34 (Android Studio offers to install it on first sync)
* Internet access for the first Gradle sync (AndroidX, CameraX, TensorFlow Lite are downloaded from Google/Maven Central)
* A physical phone is strongly recommended (camera + performance); emulators have only a virtual camera

Pinned versions: Gradle 8.7 (wrapper), Android Gradle Plugin 8.5.2, Kotlin 1.9.24, compileSdk/targetSdk 34, minSdk 24,
CameraX 1.3.4, TensorFlow Lite Task Vision 0.4.4, Material 1.12.0.

## Steps
1. **Add the model** (required) – see `MODEL_SETUP.md`. Quickest: `./gradlew downloadModel`
   (Windows: `gradlew.bat downloadModel`). It writes `app/src/main/assets/efficientdet_lite0.tflite`.
2. Open the project folder in Android Studio → *File ▸ Open*. Wait for Gradle sync.
3. Plug in a phone with USB debugging enabled and press **Run**.
4. To build the APK yourself: *Build ▸ Build Bundle(s)/APK(s) ▸ Build APK(s)*, or
   `./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`.
5. Optional unit tests (counting logic): `./gradlew testDebugUnitTest`.

## If something fails
* **"SDK location not found"** – open the project in Android Studio (it creates `local.properties`), or create it with
  `sdk.dir=/path/to/Android/sdk`.
* **Gradle sync cannot resolve `tensorflow-lite-task-vision`** – check network/proxy; the artifact is on Maven Central.
* **App opens with "AI model file is missing"** – step 1 was skipped; add the model and rebuild.
* **App opens with "model could not be loaded"** – the file is not a TFLite *detection* model with metadata
  (e.g. a raw model without metadata). Use the file from `MODEL_SETUP.md`.
* **Compile errors** – this source was never compiled by its author (see README). Send the error text to fix it; most likely
  candidates are a small API signature difference in CameraX or the Task Library.
* **16 KB page-size warning on new Android versions** – update the TensorFlow Lite dependency to a newer 0.4.x/LiteRT
  release if Android Studio reports it.
