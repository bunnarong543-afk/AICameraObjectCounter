# AI Camera Object Counter

Android app (Kotlin, CameraX, TensorFlow Lite) that detects objects through the camera and counts what is
visible **in the current frame**, fully on-device. Package: `com.rong.aicameracounter`.

> **Status – read this first**
> * The source project is complete, but it has **not been compiled or run on a device** (the environment it was
>   written in had no Android SDK and no access to Maven/Google repositories). Expect to fix small build errors on the
>   first compile. See "Verification status" below.
> * The **AI model file is not included.** The environment could not download it (network blocked). Follow
>   `MODEL_SETUP.md` – it is one file copied into `app/src/main/assets/`, or one Gradle command. Until then the app
>   starts, shows a clear "model missing" message and does not crash.
> * No APK is provided, as requested.

## Quick start
1. Install Android Studio (Koala or newer) with JDK 17 and Android SDK 34.
2. Add the model: `./gradlew downloadModel` (or see `MODEL_SETUP.md`).
3. Open this folder in Android Studio, let Gradle sync, run on a phone (API 24+).
Details: `BUILD_INSTRUCTIONS.md`.

## Features
* Live CameraX preview; front/rear switch; flash toggle (disabled with a message if the camera has no flash)
* Real EfficientDet-Lite object detection via the TensorFlow Lite Task Library (CPU)
* Bounding boxes with label and confidence, colour per category, mapped for rotation / crop / front-camera mirroring
* **Current-frame counter**: total + per-category list. Stateless per frame, never accumulates across frames
* Confidence filter, class-wise non-maximum suppression, maximum-detections cap
* Tap a category row to hide/show it (affects count and boxes); "tap to show all" restores
* Pause / resume with an explicit "DETECTION PAUSED" banner (overlay cleared, count shows "–")
* Settings (persisted): confidence, max detections, labels / boxes / confidence % on-off, diagnostics on-off,
  performance mode (battery saver / balanced / every frame), language (English / Khmer)
* Diagnostics: detection FPS, inference ms, analysis resolution
* Screenshot of preview + overlay, saved only on button tap (Pictures/AICameraCounter)
* Session statistics (peak count, average inference ms) with a reset button that is labelled as affecting
  *session statistics only* – live counts always come from the current frame
* Only permission: `CAMERA`. No `INTERNET` permission. No analytics, no cloud.

## Architecture
```
MainActivity            – wiring, permission flow, state, lifecycle cleanup
camera/CameraController – CameraX preview + analysis (KEEP_ONLY_LATEST, RGBA, 4:3)
camera/FrameAnalyzer    – analysis thread; throttling; always closes ImageProxy; reusable bitmap
detection/ObjectDetectorEngine – TFLite Task ObjectDetector wrapper, rotation, model checks
counting/ObjectCounter  – confidence filter, NMS, grouping (pure Kotlin, unit-tested)
counting/SessionStats   – optional cumulative statistics
settings/*              – AppSettings, SharedPreferences repository
ui/*                    – overlay view, category list, settings sheet
util/*                  – FPS meter, screenshot saver
```

## What the model can recognise
EfficientDet-Lite is trained on COCO: **80 categories** only, e.g. person, bicycle, car, motorcycle, bus, truck,
traffic light, bottle, cup, chair, couch, laptop, cell phone, book, cat, dog, and similar everyday objects.
Anything else (tools, specific products, food items outside COCO, etc.) will not be detected or will be mislabelled.
Labels are in English.

## Known limitations
* Not compiled / not device-tested by the author (see below). No GPU/NNAPI delegate is included on purpose (untested); CPU only.
* Counts are per frame: an object partly hidden, tiny, motion-blurred, or in a crowd may be missed or double-counted.
  Accuracy is that of EfficientDet-Lite0, not a guarantee. Not suitable for safety-critical counting.
* Overlay/preview alignment relies on preview and analysis both using 4:3; devices with unusual sensor
  configurations may show a small offset.
* The Khmer translation was written without native-speaker review; object labels stay English.
* Portrait only. Screenshot needs a drawn preview frame (PreviewView "compatible" mode is used for this).
* Release build has minification disabled (not verified with R8).

## Verification status (honest)
| Check | Result |
|---|---|
| Manual review of imports, IDs, resource names, manifest | Done by reading |
| Unit tests for counting logic (`ObjectCounterTest`) | Written, **not run** (no dependency access) |
| Gradle sync / compile / lint | **Not run** |
| Run on a device or emulator | **Not run** |
| Model download | **Failed** (network blocked) |
