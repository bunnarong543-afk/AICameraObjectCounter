// Top-level build file. Versions are pinned to a mutually compatible set:
//   Gradle 8.7 (wrapper) + AGP 8.5.2 + Kotlin 1.9.24 + JDK 17
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
