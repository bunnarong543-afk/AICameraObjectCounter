package com.rong.aicameracounter.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import androidx.camera.view.PreviewView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Saves the current preview + overlay as a PNG in Pictures/AICameraCounter.
 * Only ever called from an explicit button tap. No storage permission is needed:
 * MediaStore (API 29+) or the app's own external pictures directory (API 24-28).
 */
object ScreenshotSaver {

    /** Returns a human-readable location on success. Throws on failure. Call from the main thread to capture. */
    fun capture(previewView: PreviewView, overlay: View): Bitmap? {
        val frame = previewView.bitmap ?: return null // null until the first preview frame is drawn
        val out = frame.copy(Bitmap.Config.ARGB_8888, true) ?: return null
        val canvas = Canvas(out)
        val sx = out.width.toFloat() / overlay.width
        val sy = out.height.toFloat() / overlay.height
        canvas.scale(sx, sy)
        overlay.draw(canvas)
        return out
    }

    fun save(context: Context, bitmap: Bitmap): String {
        val name = "AICounter_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".png"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AICameraCounter")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("MediaStore insert failed")
            try {
                resolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    ?: throw IllegalStateException("Cannot open output stream")
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            } catch (t: Throwable) {
                resolver.delete(uri, null, null)
                throw t
            }
            "Pictures/AICameraCounter/$name"
        } else {
            val dir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
                ?: throw IllegalStateException("External storage unavailable")
            dir.mkdirs()
            val file = java.io.File(dir, name)
            file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            file.absolutePath
        }
    }
}
