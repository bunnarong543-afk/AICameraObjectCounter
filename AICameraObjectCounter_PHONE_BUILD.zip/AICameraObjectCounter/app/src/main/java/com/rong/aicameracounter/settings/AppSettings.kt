package com.rong.aicameracounter.settings

/**
 * Performance presets. They trade detection rate for battery/heat.
 * [threads] is the number of CPU threads given to TensorFlow Lite.
 * [minFrameIntervalMs] is the minimum time between two inference runs (0 = every frame the camera delivers).
 */
enum class PerformanceMode(val id: Int, val threads: Int, val minFrameIntervalMs: Long) {
    BATTERY_SAVER(0, 2, 200L),
    BALANCED(1, 4, 100L),
    EVERY_FRAME(2, 4, 0L);

    companion object {
        fun fromId(id: Int): PerformanceMode = values().firstOrNull { it.id == id } ?: BALANCED
    }
}

data class AppSettings(
    val confidenceThreshold: Float = 0.5f,
    val maxDetections: Int = 20,
    val showLabels: Boolean = true,
    val showBoxes: Boolean = true,
    val showConfidence: Boolean = true,
    val showDiagnostics: Boolean = true,
    val performanceMode: PerformanceMode = PerformanceMode.BALANCED,
    /** Categories the user switched off in the counter list (lower-case model labels). */
    val hiddenCategories: Set<String> = emptySet()
)
