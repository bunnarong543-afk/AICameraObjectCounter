package com.rong.aicameracounter

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.Insets
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.rong.aicameracounter.camera.CameraController
import com.rong.aicameracounter.camera.FrameAnalyzer
import com.rong.aicameracounter.counting.CategoryCount
import com.rong.aicameracounter.counting.CountSummary
import com.rong.aicameracounter.counting.ObjectCounter
import com.rong.aicameracounter.counting.SessionStats
import com.rong.aicameracounter.databinding.ActivityMainBinding
import com.rong.aicameracounter.detection.FrameDetections
import com.rong.aicameracounter.detection.ObjectDetectorEngine
import com.rong.aicameracounter.settings.AppSettings
import com.rong.aicameracounter.settings.SettingsRepository
import com.rong.aicameracounter.ui.CategoryAdapter
import com.rong.aicameracounter.ui.SettingsSheet
import com.rong.aicameracounter.util.FpsMeter
import com.rong.aicameracounter.util.ScreenshotSaver
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity(), CameraController.Listener {

    private enum class Status { LOADING, RUNNING, PAUSED, ERROR }

    private lateinit var binding: ActivityMainBinding
    private lateinit var settingsRepo: SettingsRepository
    private lateinit var adapter: CategoryAdapter

    // One thread does ALL TensorFlow Lite work (init, inference, close).
    private val analysisExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private lateinit var engine: ObjectDetectorEngine
    private lateinit var analyzer: FrameAnalyzer
    private var camera: CameraController? = null

    private val counter = ObjectCounter()
    private val sessionStats = SessionStats()
    private val fps = FpsMeter()

    private var lastFrame: FrameDetections? = null
    private var modelReady = false
    private var modelLoading = false
    private var paused = false
    private var fatalError = false
    private var cameraRunning = false
    private var loadedThreads = 0
    private var permissionRequested = false

    private val settingsListener: (AppSettings) -> Unit = { onSettingsChanged(it) }
    private var lastSettings: AppSettings? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) onPermissionGranted() else showPermissionDenied()
        }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        applyInsets()

        settingsRepo = SettingsRepository.get(this)
        lastSettings = settingsRepo.current

        engine = ObjectDetectorEngine(applicationContext)
        analyzer = FrameAnalyzer(
            engine,
            onResult = { result -> runOnUiThread { onFrameResult(result) } },
            onError = { msg -> runOnUiThread { onInferenceFailed(msg) } }
        )
        analyzer.minIntervalMs = settingsRepo.current.performanceMode.minFrameIntervalMs

        adapter = CategoryAdapter(binding.overlay::colorFor) { item -> toggleCategory(item) }
        binding.categoryList.layoutManager = LinearLayoutManager(this)
        binding.categoryList.adapter = adapter
        binding.categoryList.itemAnimator = null

        wireControls()
        applyOverlaySettings(settingsRepo.current)
        settingsRepo.addListener(settingsListener)
        updateSessionStatsText()
        updateStatus(Status.LOADING)
        showIdleCounter()

        loadModel()

        if (hasCameraPermission()) onPermissionGranted() else showRationale()
    }

    override fun onResume() {
        super.onResume()
        // Returning from system settings after granting the permission there.
        if (camera == null && hasCameraPermission()) onPermissionGranted()
    }

    override fun onDestroy() {
        settingsRepo.removeListener(settingsListener)
        camera?.shutdown()
        camera = null
        // Close native resources on the thread that owns them, then stop the thread.
        analysisExecutor.execute {
            analyzer.enabled = false
            analyzer.release()
            engine.close()
        }
        analysisExecutor.shutdown()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ setup

    private fun applyInsets() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val topBase = binding.topContainer.paddingTop
        val bottomBase = binding.bottomContainer.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, windowInsets ->
            val bars: Insets = windowInsets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            binding.topContainer.setPadding(
                binding.topContainer.paddingLeft, topBase + bars.top,
                binding.topContainer.paddingRight, binding.topContainer.paddingBottom
            )
            binding.bottomContainer.setPadding(
                binding.bottomContainer.paddingLeft, binding.bottomContainer.paddingTop,
                binding.bottomContainer.paddingRight, bottomBase + bars.bottom
            )
            WindowInsetsCompat.CONSUMED
        }
    }

    private fun wireControls() {
        binding.btnPause.setOnClickListener { setPaused(!paused) }
        binding.btnSwitch.setOnClickListener {
            camera?.switchCamera()
        }
        binding.btnFlash.setOnClickListener {
            val on = camera?.toggleTorch()
            if (on == null) {
                Toast.makeText(this, R.string.flash_unavailable, Toast.LENGTH_SHORT).show()
            } else {
                updateFlashButton(on, true)
            }
        }
        binding.btnSettings.setOnClickListener {
            val sheet = SettingsSheet()
            sheet.modelNameProvider = { engine.modelName }
            sheet.show(supportFragmentManager, SettingsSheet.TAG)
        }
        binding.btnScreenshot.setOnClickListener { takeScreenshot() }
        binding.btnResetStats.setOnClickListener {
            sessionStats.reset()
            updateSessionStatsText()
            Toast.makeText(this, R.string.session_reset_done, Toast.LENGTH_LONG).show()
        }
        binding.tvHiddenInfo.setOnClickListener {
            settingsRepo.update { it.copy(hiddenCategories = emptySet()) }
        }
    }

    // ------------------------------------------------------------------ permission

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun showRationale() {
        showMessage(
            getString(R.string.permission_title),
            getString(R.string.permission_rationale),
            getString(R.string.permission_grant)
        ) {
            permissionRequested = true
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun showPermissionDenied() {
        // After a denial, shouldShowRequestPermissionRationale() is false only if the user chose
        // "don't ask again" (or the system will not show the dialog any more).
        val canAskAgain = androidx.core.app.ActivityCompat.shouldShowRequestPermissionRationale(
            this, Manifest.permission.CAMERA
        )
        if (canAskAgain || !permissionRequested) {
            showRationale()
        } else {
            showMessage(
                getString(R.string.permission_title),
                getString(R.string.permission_denied_permanent),
                getString(R.string.permission_open_settings)
            ) {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
                )
            }
        }
    }

    private fun onPermissionGranted() {
        if (camera != null) {
            hideMessage()
            return
        }
        hideMessage()
        val controller = CameraController(
            context = this,
            lifecycleOwner = this,
            previewView = binding.previewView,
            analysisExecutor = analysisExecutor,
            analyzer = analyzer,
            listener = this
        )
        camera = controller
        controller.start()
    }

    // ------------------------------------------------------------------ model

    private fun loadModel() {
        if (modelLoading || isFinishing) return
        modelLoading = true
        modelReady = false
        fatalError = false
        analyzer.enabled = false
        binding.loadingOverlay.visibility = View.VISIBLE
        updateStatus(Status.LOADING)
        val threads = settingsRepo.current.performanceMode.threads
        analysisExecutor.execute {
            val result = engine.initialize(threads)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                modelLoading = false
                binding.loadingOverlay.visibility = View.GONE
                when (result) {
                    is ObjectDetectorEngine.InitResult.Ready -> {
                        modelReady = true
                        loadedThreads = result.threads
                        hideMessageIfError()
                        refreshAnalyzerState()
                        // The user may have changed performance mode while loading.
                        val wanted = settingsRepo.current.performanceMode.threads
                        if (wanted != loadedThreads) loadModel()
                    }
                    is ObjectDetectorEngine.InitResult.Failed -> {
                        fatalError = true
                        updateStatus(Status.ERROR)
                        val body = when (result.kind) {
                            ObjectDetectorEngine.FailureKind.MODEL_MISSING -> getString(R.string.error_model_missing)
                            ObjectDetectorEngine.FailureKind.MODEL_INVALID -> getString(R.string.error_model_invalid)
                        } + "\n\n" + getString(
                            R.string.error_model_detail,
                            result.modelName ?: "-", result.detail
                        )
                        showMessage(getString(R.string.error_title), body, getString(R.string.action_retry)) {
                            hideMessage()
                            loadModel()
                        }
                    }
                }
            }
        }
    }

    private fun onInferenceFailed(message: String) {
        if (isDestroyed) return
        fatalError = true
        updateStatus(Status.ERROR)
        showMessage(
            getString(R.string.error_title),
            getString(R.string.error_inference, message),
            getString(R.string.action_retry)
        ) {
            hideMessage()
            fatalError = false
            refreshAnalyzerState()
        }
    }

    /** Single place that decides whether frames are analysed. */
    private fun refreshAnalyzerState() {
        val active = modelReady && !modelLoading && !paused && !fatalError && cameraRunning
        analyzer.enabled = active
        when {
            fatalError -> updateStatus(Status.ERROR)
            modelLoading || !modelReady -> updateStatus(Status.LOADING)
            paused -> updateStatus(Status.PAUSED)
            else -> updateStatus(Status.RUNNING)
        }
    }

    // ------------------------------------------------------------------ pause / resume

    private fun setPaused(value: Boolean) {
        paused = value
        binding.tvPausedBanner.visibility = if (paused) View.VISIBLE else View.GONE
        binding.btnPause.setImageResource(if (paused) R.drawable.ic_play else R.drawable.ic_pause)
        binding.btnPause.contentDescription =
            getString(if (paused) R.string.action_resume else R.string.action_pause)
        if (paused) {
            // The preview stays live, so stale boxes would be misleading: clear them.
            lastFrame = null
            binding.overlay.clear()
            fps.reset()
            showIdleCounter()
        }
        refreshAnalyzerState()
    }

    // ------------------------------------------------------------------ results

    private fun onFrameResult(result: FrameDetections) {
        if (isDestroyed || paused) return // a result produced just before pausing is discarded
        lastFrame = result
        fps.tick()
        val summary = render(result)
        sessionStats.record(summary.total, result.inferenceMs)
        updateSessionStatsText()
        updateDiagnostics(result)
    }

    /** Applies the current settings to [frame]; returns the summary that was drawn. */
    private fun render(frame: FrameDetections): CountSummary {
        val settings = settingsRepo.current
        val summary = counter.summarize(frame.detections, settings)
        binding.overlay.setDetections(
            summary.visibleDetections, frame.frameWidth, frame.frameHeight,
            camera?.isFrontCamera == true
        )
        binding.tvTotal.text = summary.total.toString()
        adapter.submitList(summary.categories)

        val hasCategories = summary.categories.isNotEmpty()
        binding.categoryList.visibility = if (hasCategories) View.VISIBLE else View.GONE
        binding.tvEmpty.visibility = if (hasCategories) View.GONE else View.VISIBLE
        binding.tvEmpty.setText(R.string.no_objects)

        val hiddenCount = settings.hiddenCategories.size
        if (hiddenCount > 0) {
            binding.tvHiddenInfo.text = getString(R.string.hidden_categories, hiddenCount)
            binding.tvHiddenInfo.visibility = View.VISIBLE
        } else {
            binding.tvHiddenInfo.visibility = View.GONE
        }
        return summary
    }

    private fun showIdleCounter() {
        binding.tvTotal.text = if (paused) getString(R.string.total_paused_placeholder) else "0"
        adapter.submitList(emptyList())
        binding.categoryList.visibility = View.GONE
        binding.tvEmpty.visibility = View.VISIBLE
        binding.tvEmpty.setText(if (paused) R.string.paused_empty else R.string.no_objects)
        binding.tvHiddenInfo.visibility = View.GONE
    }

    private fun toggleCategory(item: CategoryCount) {
        settingsRepo.update { s ->
            val hidden = s.hiddenCategories.toMutableSet()
            if (!hidden.remove(item.label)) hidden.add(item.label)
            s.copy(hiddenCategories = hidden)
        }
    }

    // ------------------------------------------------------------------ settings

    private fun onSettingsChanged(s: AppSettings) {
        if (isDestroyed) return
        val previous = lastSettings
        lastSettings = s
        applyOverlaySettings(s)
        analyzer.minIntervalMs = s.performanceMode.minFrameIntervalMs
        if (previous?.performanceMode?.threads != s.performanceMode.threads && !modelLoading) {
            loadModel()
        }
        if (!s.showDiagnostics) binding.tvDiagnostics.visibility = View.GONE
        // Re-apply filters to the last frame immediately instead of waiting for the next one.
        lastFrame?.let { if (!paused) render(it) }
        lastFrame?.let { updateDiagnostics(it) }
    }

    private fun applyOverlaySettings(s: AppSettings) {
        binding.overlay.showBoxes = s.showBoxes
        binding.overlay.showLabels = s.showLabels
        binding.overlay.showConfidence = s.showConfidence
        binding.tvDiagnostics.visibility = if (s.showDiagnostics) View.VISIBLE else View.GONE
    }

    // ------------------------------------------------------------------ status & diagnostics

    private fun updateStatus(status: Status) {
        val (text, color) = when (status) {
            Status.LOADING -> R.string.status_loading to R.color.status_loading
            Status.RUNNING -> R.string.status_running to R.color.neon_green
            Status.PAUSED -> R.string.status_paused to R.color.status_paused
            Status.ERROR -> R.string.status_error to R.color.status_error
        }
        binding.tvStatus.setText(text)
        binding.statusDot.backgroundTintList =
            android.content.res.ColorStateList.valueOf(ContextCompat.getColor(this, color))
    }

    private fun updateDiagnostics(frame: FrameDetections) {
        if (!settingsRepo.current.showDiagnostics) return
        binding.tvDiagnostics.text = getString(
            R.string.diagnostics,
            String.format(Locale.US, "%.1f", fps.fps),
            frame.inferenceMs.toInt(),
            frame.frameWidth,
            frame.frameHeight
        )
    }

    private fun updateSessionStatsText() {
        binding.tvSessionStats.text = getString(
            R.string.session_stats, sessionStats.peakTotal, sessionStats.averageInferenceMs.toInt()
        )
    }

    private fun updateFlashButton(on: Boolean, supported: Boolean) {
        binding.btnFlash.setImageResource(if (on) R.drawable.ic_flash_on else R.drawable.ic_flash_off)
        binding.btnFlash.contentDescription =
            getString(if (on) R.string.action_flash_off else R.string.action_flash_on)
        binding.btnFlash.alpha = if (supported) 1f else 0.4f
    }

    // ------------------------------------------------------------------ screenshot

    private fun takeScreenshot() {
        val bitmap = try {
            ScreenshotSaver.capture(binding.previewView, binding.overlay)
        } catch (t: Throwable) {
            null
        }
        if (bitmap == null) {
            Toast.makeText(this, R.string.screenshot_not_ready, Toast.LENGTH_SHORT).show()
            return
        }
        val appContext = applicationContext
        Thread {
            val message = try {
                appContext.getString(R.string.screenshot_saved, ScreenshotSaver.save(appContext, bitmap))
            } catch (t: Throwable) {
                appContext.getString(R.string.screenshot_failed, t.message ?: t.javaClass.simpleName)
            } finally {
                bitmap.recycle()
            }
            runOnUiThread {
                if (!isDestroyed) Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    // ------------------------------------------------------------------ message overlay

    private fun showMessage(title: String, body: String, button: String, action: () -> Unit) {
        binding.tvMessageTitle.text = title
        binding.tvMessageBody.text = body
        binding.btnMessagePrimary.text = button
        binding.btnMessagePrimary.setOnClickListener { action() }
        binding.messageOverlay.visibility = View.VISIBLE
    }

    private fun hideMessage() {
        binding.messageOverlay.visibility = View.GONE
    }

    /** Hides the overlay only if it is showing an error (not the permission prompt). */
    private fun hideMessageIfError() {
        if (hasCameraPermission() || camera != null) hideMessage()
    }

    // ------------------------------------------------------------------ CameraController.Listener

    override fun onCameraReady(isFrontCamera: Boolean, hasFlash: Boolean) {
        cameraRunning = true
        lastFrame = null
        binding.overlay.clear()
        updateFlashButton(false, hasFlash)
        refreshAnalyzerState()
    }

    override fun onCameraError(kind: CameraController.ErrorKind, detail: String) {
        cameraRunning = false
        refreshAnalyzerState()
        val body = when (kind) {
            CameraController.ErrorKind.NO_CAMERA -> getString(R.string.error_camera_missing)
            CameraController.ErrorKind.START_FAILED -> getString(R.string.error_camera, detail)
        }
        showMessage(getString(R.string.error_title), body, getString(R.string.action_retry)) {
            hideMessage()
            camera?.shutdown()
            camera = null
            onPermissionGranted()
        }
    }
}
