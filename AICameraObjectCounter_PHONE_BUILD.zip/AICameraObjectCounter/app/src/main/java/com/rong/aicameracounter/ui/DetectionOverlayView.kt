package com.rong.aicameracounter.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import com.rong.aicameracounter.detection.DetectedObject
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Draws detection boxes over the PreviewView.
 *
 * Coordinate mapping: boxes arrive in pixels of the upright analysis frame. The PreviewView uses
 * FILL_CENTER (scale to cover, centre-crop), and preview and analysis share the same 4:3 field of
 * view, so a single uniform scale plus a centring offset maps frame -> view:
 *   scale = max(viewW / frameW, viewH / frameH)
 *   offset = (view - frame * scale) / 2        (negative when the frame is cropped)
 * For the front camera the preview is mirrored, so x is flipped.
 */
class DetectionOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var detections: List<DetectedObject> = emptyList()
    private var frameW = 0
    private var frameH = 0
    private var mirror = false

    var showBoxes = true
        set(v) { field = v; invalidate() }
    var showLabels = true
        set(v) { field = v; invalidate() }
    var showConfidence = true
        set(v) { field = v; invalidate() }

    private val density = resources.displayMetrics.density
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = 12f * density
        isFakeBoldText = true
    }
    private val rect = RectF()
    private val palette = intArrayOf(
        0xFF39FF88.toInt(), 0xFF22E5FF.toInt(), 0xFFFFD54A.toInt(),
        0xFFFF7AC6.toInt(), 0xFFB388FF.toInt(), 0xFFFF9E40.toInt()
    )

    /** Colour is derived from the label so a category keeps its colour from frame to frame. */
    fun colorFor(label: String): Int = palette[(label.hashCode() and 0x7fffffff) % palette.size]

    fun setDetections(list: List<DetectedObject>, frameWidth: Int, frameHeight: Int, mirrored: Boolean) {
        detections = list
        frameW = frameWidth
        frameH = frameHeight
        mirror = mirrored
        invalidate()
    }

    fun clear() {
        detections = emptyList()
        invalidate()
    }

    /** Overlay -> view mapping, exposed for the screenshot path. */
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (detections.isEmpty() || frameW <= 0 || frameH <= 0 || width == 0 || height == 0) return
        if (!showBoxes && !showLabels && !showConfidence) return

        val scale = max(width.toFloat() / frameW, height.toFloat() / frameH)
        val offX = (width - frameW * scale) / 2f
        val offY = (height - frameH * scale) / 2f

        for (d in detections) {
            var l = d.left * scale + offX
            var r = d.right * scale + offX
            val t = d.top * scale + offY
            val b = d.bottom * scale + offY
            if (mirror) {
                val nl = width - r
                val nr = width - l
                l = nl
                r = nr
            }
            rect.set(l, t, r, b)
            val color = colorFor(d.label)

            if (showBoxes) {
                boxPaint.color = color
                canvas.drawRoundRect(rect, 6f * density, 6f * density, boxPaint)
            }

            val text = buildLabel(d)
            if (text.isNotEmpty()) {
                val pad = 4f * density
                val tw = textPaint.measureText(text)
                val th = textPaint.textSize
                val boxW = tw + pad * 2
                val boxH = th + pad * 1.5f
                var lx = rect.left.coerceIn(0f, max(0f, width - boxW))
                var ly = rect.top - boxH
                if (ly < 0f) ly = rect.top.coerceAtLeast(0f) // box touches the top: put the label inside
                if (ly + boxH > height) ly = height - boxH
                fillPaint.color = color
                canvas.drawRoundRect(lx, ly, lx + boxW, ly + boxH, 4f * density, 4f * density, fillPaint)
                canvas.drawText(text, lx + pad, ly + boxH - pad * 0.9f, textPaint)
            }
        }
    }

    private fun buildLabel(d: DetectedObject): String {
        val sb = StringBuilder()
        if (showLabels) sb.append(d.label.replaceFirstChar { it.uppercase() })
        if (showConfidence) {
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append((d.score * 100).roundToInt()).append('%')
        }
        return sb.toString()
    }
}
