package com.rong.aicameracounter.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.rong.aicameracounter.R
import com.rong.aicameracounter.databinding.SheetSettingsBinding
import com.rong.aicameracounter.settings.PerformanceMode
import com.rong.aicameracounter.settings.SettingsRepository
import kotlin.math.roundToInt

/** Settings bottom sheet. Every control writes straight to [SettingsRepository]. */
class SettingsSheet : BottomSheetDialogFragment() {

    private var _binding: SheetSettingsBinding? = null
    private val binding get() = _binding!!

    /** Supplied by MainActivity so the sheet can show which model file is active. */
    var modelNameProvider: () -> String? = { null }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, state: Bundle?): View {
        _binding = SheetSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val repo = SettingsRepository.get(requireContext())
        val s = repo.current

        binding.sliderConfidence.value = s.confidenceThreshold.coerceIn(0.1f, 0.95f)
        updateConfidenceText(s.confidenceThreshold)
        binding.sliderConfidence.addOnChangeListener { _, value, fromUser ->
            if (fromUser) repo.update { it.copy(confidenceThreshold = value) }
            updateConfidenceText(value)
        }

        binding.sliderMax.value = s.maxDetections.toFloat().coerceIn(1f, 25f)
        updateMaxText(s.maxDetections)
        binding.sliderMax.addOnChangeListener { _, value, fromUser ->
            if (fromUser) repo.update { it.copy(maxDetections = value.toInt()) }
            updateMaxText(value.toInt())
        }

        binding.switchLabels.isChecked = s.showLabels
        binding.switchLabels.setOnCheckedChangeListener { _, c -> repo.update { it.copy(showLabels = c) } }
        binding.switchBoxes.isChecked = s.showBoxes
        binding.switchBoxes.setOnCheckedChangeListener { _, c -> repo.update { it.copy(showBoxes = c) } }
        binding.switchConfidence.isChecked = s.showConfidence
        binding.switchConfidence.setOnCheckedChangeListener { _, c -> repo.update { it.copy(showConfidence = c) } }
        binding.switchDiagnostics.isChecked = s.showDiagnostics
        binding.switchDiagnostics.setOnCheckedChangeListener { _, c -> repo.update { it.copy(showDiagnostics = c) } }

        // Performance mode
        binding.toggleMode.check(
            when (s.performanceMode) {
                PerformanceMode.BATTERY_SAVER -> R.id.btnModeBattery
                PerformanceMode.BALANCED -> R.id.btnModeBalanced
                PerformanceMode.EVERY_FRAME -> R.id.btnModeAccurate
            }
        )
        updateModeHint(s.performanceMode)
        binding.toggleMode.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            val mode = when (id) {
                R.id.btnModeBattery -> PerformanceMode.BATTERY_SAVER
                R.id.btnModeAccurate -> PerformanceMode.EVERY_FRAME
                else -> PerformanceMode.BALANCED
            }
            repo.update { it.copy(performanceMode = mode) }
            updateModeHint(mode)
        }

        // Language: AppCompat stores the choice and recreates the activity.
        val isKhmer = AppCompatDelegate.getApplicationLocales().toLanguageTags().startsWith("km")
        binding.toggleLanguage.check(if (isKhmer) R.id.btnLangKm else R.id.btnLangEn)
        binding.toggleLanguage.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            val tag = if (id == R.id.btnLangKm) "km" else "en"
            val current = AppCompatDelegate.getApplicationLocales().toLanguageTags()
            if (!current.startsWith(tag)) {
                AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
            }
        }

        binding.tvModelInfo.text = getString(
            R.string.about_model_text,
            modelNameProvider() ?: getString(R.string.about_model_unknown)
        )
        binding.btnDone.setOnClickListener { dismiss() }
    }

    private fun updateConfidenceText(v: Float) {
        binding.tvConfidenceValue.text = getString(R.string.settings_confidence, (v * 100).roundToInt())
    }

    private fun updateMaxText(v: Int) {
        binding.tvMaxValue.text = getString(R.string.settings_max_detections, v)
    }

    private fun updateModeHint(mode: PerformanceMode) {
        binding.tvModeHint.setText(
            when (mode) {
                PerformanceMode.BATTERY_SAVER -> R.string.perf_battery_hint
                PerformanceMode.BALANCED -> R.string.perf_balanced_hint
                PerformanceMode.EVERY_FRAME -> R.string.perf_accurate_hint
            }
        )
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }

    companion object {
        const val TAG = "SettingsSheet"
    }
}
