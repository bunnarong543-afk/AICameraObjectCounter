package com.rong.aicameracounter.counting

/**
 * Optional cumulative statistics for the current app session (peak simultaneous count and
 * average inference time). These are NOT the live counts: resetting them never changes
 * what the detector currently sees.
 */
class SessionStats {
    var peakTotal: Int = 0
        private set
    var frames: Long = 0
        private set
    private var inferenceSumMs: Long = 0

    val averageInferenceMs: Long
        get() = if (frames == 0L) 0L else inferenceSumMs / frames

    fun record(total: Int, inferenceMs: Long) {
        frames++
        inferenceSumMs += inferenceMs
        if (total > peakTotal) peakTotal = total
    }

    fun reset() {
        peakTotal = 0
        frames = 0
        inferenceSumMs = 0
    }
}
