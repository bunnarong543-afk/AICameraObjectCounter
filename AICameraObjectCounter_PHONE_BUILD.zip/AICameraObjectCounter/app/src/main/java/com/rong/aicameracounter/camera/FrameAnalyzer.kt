package com.rong.aicameracounter.camera

import android.graphics.Bitmap
import android.os.SystemClock
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.rong.aicameracounter.detection.FrameDetections
import com.rong.aicameracounter.detection.ObjectDetectorEngine

/**
 * CameraX analyzer. Runs on the analysis executor (never the main thread).
 *
 * Every code path closes the ImageProxy (single `finally`). Frames that arrive while detection is
 * paused, while the model is loading, or sooner than [minIntervalMs] after the last run are
 * dropped immediately, which keeps the camera pipeline flowing.
 *
 * [onResult] and [onError] are invoked on the analysis thread; the caller must hop to the main thread.
 */
class FrameAnalyzer(
    private val engine: ObjectDetectorEngine,
    private val onResult: (FrameDetections) -> Unit,
    private val onError: (String) -> Unit
) : ImageAnalysis.Analyzer {

    /** False while paused or while the model is (re)loading. */
    @Volatile
    var enabled: Boolean = false

    @Volatile
    var minIntervalMs: Long = 0L

    private var lastRunMs = 0L
    private var consecutiveErrors = 0
    private var reusableBitmap: Bitmap? = null

    override fun analyze(image: ImageProxy) {
        try {
            if (!enabled || !engine.isReady) return
            val now = SystemClock.elapsedRealtime()
            if (now - lastRunMs < minIntervalMs) return
            lastRunMs = now

            val bitmap = toBitmap(image)
            val result = engine.detect(bitmap, image.imageInfo.rotationDegrees)
            consecutiveErrors = 0
            if (result != null) onResult(result)
        } catch (t: Throwable) {
            consecutiveErrors++
            if (consecutiveErrors >= MAX_CONSECUTIVE_ERRORS) {
                enabled = false
                consecutiveErrors = 0
                onError(t.message ?: t.javaClass.simpleName)
            }
        } finally {
            image.close()
        }
    }

    /**
     * Copies the RGBA frame into a reusable bitmap (no allocation per frame in the common case).
     * Falls back to CameraX's own conversion when the plane buffer is not laid out as expected.
     */
    private fun toBitmap(image: ImageProxy): Bitmap {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val buffer = plane.buffer
        if (pixelStride == 4) {
            val rowPixels = plane.rowStride / 4
            val needed = rowPixels * 4 * image.height
            if (buffer.remaining() >= needed) {
                var bmp = reusableBitmap
                if (bmp == null || bmp.width != rowPixels || bmp.height != image.height) {
                    bmp?.recycle()
                    bmp = Bitmap.createBitmap(rowPixels, image.height, Bitmap.Config.ARGB_8888)
                    reusableBitmap = bmp
                }
                buffer.rewind()
                bmp.copyPixelsFromBuffer(buffer)
                // Rows may be padded; crop only in that rare case.
                return if (rowPixels == image.width) bmp
                else Bitmap.createBitmap(bmp, 0, 0, image.width, image.height)
            }
        }
        return image.toBitmap()
    }

    /** Releases the reusable bitmap. Call on the analysis thread after the last frame. */
    fun release() {
        reusableBitmap?.recycle()
        reusableBitmap = null
    }

    companion object {
        private const val MAX_CONSECUTIVE_ERRORS = 3
    }
}
