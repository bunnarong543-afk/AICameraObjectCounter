package com.rong.aicameracounter.settings

import android.content.Context
import android.content.SharedPreferences
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Persists [AppSettings] in SharedPreferences and notifies listeners on change.
 * Use from the main thread.
 */
class SettingsRepository private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val listeners = CopyOnWriteArrayList<(AppSettings) -> Unit>()

    var current: AppSettings = load()
        private set

    fun update(transform: (AppSettings) -> AppSettings) {
        val next = transform(current)
        if (next == current) return
        current = next
        save(next)
        listeners.forEach { it(next) }
    }

    fun addListener(listener: (AppSettings) -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: (AppSettings) -> Unit) {
        listeners.remove(listener)
    }

    private fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            confidenceThreshold = prefs.getFloat(KEY_CONFIDENCE, d.confidenceThreshold).coerceIn(0.1f, 0.95f),
            maxDetections = prefs.getInt(KEY_MAX, d.maxDetections).coerceIn(1, 25),
            showLabels = prefs.getBoolean(KEY_LABELS, d.showLabels),
            showBoxes = prefs.getBoolean(KEY_BOXES, d.showBoxes),
            showConfidence = prefs.getBoolean(KEY_CONF_PCT, d.showConfidence),
            showDiagnostics = prefs.getBoolean(KEY_DIAG, d.showDiagnostics),
            performanceMode = PerformanceMode.fromId(prefs.getInt(KEY_PERF, d.performanceMode.id)),
            hiddenCategories = prefs.getStringSet(KEY_HIDDEN, emptySet())?.toSet() ?: emptySet()
        )
    }

    private fun save(s: AppSettings) {
        prefs.edit()
            .putFloat(KEY_CONFIDENCE, s.confidenceThreshold)
            .putInt(KEY_MAX, s.maxDetections)
            .putBoolean(KEY_LABELS, s.showLabels)
            .putBoolean(KEY_BOXES, s.showBoxes)
            .putBoolean(KEY_CONF_PCT, s.showConfidence)
            .putBoolean(KEY_DIAG, s.showDiagnostics)
            .putInt(KEY_PERF, s.performanceMode.id)
            // Always store a fresh copy: SharedPreferences must not be handed a set it may later see mutated.
            .putStringSet(KEY_HIDDEN, HashSet(s.hiddenCategories))
            .apply()
    }

    companion object {
        private const val PREFS_NAME = "ai_camera_counter_settings"
        private const val KEY_CONFIDENCE = "confidence"
        private const val KEY_MAX = "max_detections"
        private const val KEY_LABELS = "show_labels"
        private const val KEY_BOXES = "show_boxes"
        private const val KEY_CONF_PCT = "show_confidence"
        private const val KEY_DIAG = "show_diagnostics"
        private const val KEY_PERF = "performance_mode"
        private const val KEY_HIDDEN = "hidden_categories"

        @Volatile
        private var instance: SettingsRepository? = null

        fun get(context: Context): SettingsRepository =
            instance ?: synchronized(this) {
                instance ?: SettingsRepository(context.applicationContext).also { instance = it }
            }
    }
}
