package com.rong.aicameracounter.util

import android.os.SystemClock

/** Smoothed rate of delivered detection results (not the camera preview frame rate). */
class FpsMeter {
    var fps: Float = 0f
        private set
    private var lastTickMs = 0L

    fun tick() {
        val now = SystemClock.elapsedRealtime()
        if (lastTickMs != 0L) {
            val dt = now - lastTickMs
            if (dt > 0) {
                val instant = 1000f / dt
                fps = if (fps == 0f) instant else fps * 0.8f + instant * 0.2f
            }
        }
        lastTickMs = now
    }

    fun reset() {
        fps = 0f
        lastTickMs = 0L
    }
}
