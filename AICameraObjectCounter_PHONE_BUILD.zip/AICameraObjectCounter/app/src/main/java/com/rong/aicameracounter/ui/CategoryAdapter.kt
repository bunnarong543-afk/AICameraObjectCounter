package com.rong.aicameracounter.ui

import android.graphics.PorterDuff
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.rong.aicameracounter.R
import com.rong.aicameracounter.counting.CategoryCount

/** Per-category rows. Tapping a row hides/shows that category. */
class CategoryAdapter(
    private val colorFor: (String) -> Int,
    private val onToggle: (CategoryCount) -> Unit
) : ListAdapter<CategoryCount, CategoryAdapter.Holder>(Diff) {

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val dot: View = view.findViewById(R.id.colorDot)
        val name: TextView = view.findViewById(R.id.tvName)
        val count: TextView = view.findViewById(R.id.tvCount)
        val eye: ImageView = view.findViewById(R.id.ivVisibility)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_category, parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = getItem(position)
        val label = item.label.replaceFirstChar { it.uppercase() }
        holder.name.text = label
        holder.count.text = item.count.toString()
        holder.dot.background.mutate().setColorFilter(colorFor(item.label), PorterDuff.Mode.SRC_IN)
        holder.eye.setImageResource(if (item.visible) R.drawable.ic_visibility else R.drawable.ic_visibility_off)
        val alpha = if (item.visible) 1f else 0.4f
        holder.name.alpha = alpha
        holder.count.alpha = alpha
        holder.dot.alpha = alpha
        holder.itemView.contentDescription =
            holder.itemView.context.getString(R.string.toggle_category_desc, label)
        holder.itemView.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION && pos in 0 until itemCount) onToggle(getItem(pos))
        }
    }

    private object Diff : DiffUtil.ItemCallback<CategoryCount>() {
        override fun areItemsTheSame(a: CategoryCount, b: CategoryCount) = a.label == b.label
        override fun areContentsTheSame(a: CategoryCount, b: CategoryCount) = a == b
    }
}
