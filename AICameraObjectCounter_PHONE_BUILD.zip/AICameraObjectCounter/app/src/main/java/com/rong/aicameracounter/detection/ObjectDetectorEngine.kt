package com.rong.aicameracounter.detection

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import org.tensorflow.lite.DataType
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.Rot90Op
import org.tensorflow.lite.task.core.BaseOptions
import org.tensorflow.lite.task.vision.detector.ObjectDetector

/**
 * Thin wrapper around the TensorFlow Lite Task Library [ObjectDetector].
 *
 * Threading: [initialize], [detect] and [close] must all be called from the SAME single
 * background thread (the analysis executor). Only [isReady] and [modelName] may be read
 * from other threads.
 *
 * The model must be a TFLite object-detection model WITH metadata (labels, normalisation),
 * such as the EfficientDet-Lite family. See MODEL_SETUP.md.
 */
class ObjectDetectorEngine(private val context: Context) {

    enum class FailureKind { MODEL_MISSING, MODEL_INVALID }

    sealed interface InitResult {
        data class Ready(val modelName: String, val threads: Int) : InitResult
        data class Failed(val kind: FailureKind, val modelName: String?, val detail: String) : InitResult
    }

    @Volatile
    var isReady: Boolean = false
        private set

    @Volatile
    var modelName: String? = null
        private set

    /** Thread count of the currently loaded detector (valid when [isReady]). */
    @Volatile
    var activeThreads: Int = 0
        private set

    private var detector: ObjectDetector? = null
    private val tensorImage = TensorImage(DataType.UINT8)
    private var processor: ImageProcessor? = null
    private var processorRotation = -1

    /** Loads (or reloads) the model. Blocking; call on the analysis thread. */
    fun initialize(numThreads: Int): InitResult {
        close()
        val name = findModelAsset()
            ?: return InitResult.Failed(
                FailureKind.MODEL_MISSING, null,
                "Looked for: ${MODEL_CANDIDATES.joinToString()}"
            )
        return try {
            val base = BaseOptions.builder().setNumThreads(numThreads).build()
            val options = ObjectDetector.ObjectDetectorOptions.builder()
                .setBaseOptions(base)
                .setMaxResults(MAX_RESULTS)
                // Low floor; the user's confidence slider is applied later by ObjectCounter,
                // so moving the slider takes effect immediately without reloading the model.
                .setScoreThreshold(SCORE_FLOOR)
                .build()
            detector = ObjectDetector.createFromFileAndOptions(context, name, options)
            modelName = name
            activeThreads = numThreads
            isReady = true
            InitResult.Ready(name, numThreads)
        } catch (t: Throwable) {
            isReady = false
            detector = null
            modelName = name
            InitResult.Failed(FailureKind.MODEL_INVALID, name, t.message ?: t.javaClass.simpleName)
        }
    }

    /**
     * Runs detection on [bitmap] (RGBA, as delivered by CameraX). [rotationDegrees] is the clockwise
     * rotation needed to make the image upright (ImageInfo.rotationDegrees). Returned boxes are in
     * the coordinate system of the upright image.
     */
    fun detect(bitmap: Bitmap, rotationDegrees: Int): FrameDetections? {
        val d = detector ?: return null
        val start = SystemClock.elapsedRealtime()

        if (processor == null || processorRotation != rotationDegrees) {
            // Rot90Op(k) rotates counter-clockwise by k * 90 degrees. CameraX reports the clockwise
            // rotation needed to make the frame upright, so k = (360 - rotation) / 90 (kept non-negative).
            val k = ((360 - rotationDegrees) % 360) / 90
            processor = ImageProcessor.Builder().add(Rot90Op(k)).build()
            processorRotation = rotationDegrees
        }
        tensorImage.load(bitmap)
        val upright = processor!!.process(tensorImage)

        val results = d.detect(upright)
        val out = ArrayList<DetectedObject>(results.size)
        for (r in results) {
            val category = r.categories.firstOrNull() ?: continue
            val label = category.label
            // The COCO label map shipped with EfficientDet contains "???" placeholders.
            if (label.isNullOrBlank() || label == "???") continue
            val box = r.boundingBox
            out.add(DetectedObject(label, category.score, box.left, box.top, box.right, box.bottom))
        }
        return FrameDetections(
            detections = out,
            frameWidth = upright.width,
            frameHeight = upright.height,
            inferenceMs = SystemClock.elapsedRealtime() - start
        )
    }

    fun close() {
        isReady = false
        try {
            detector?.close()
        } catch (_: Throwable) {
            // Nothing useful to do if native cleanup fails.
        }
        detector = null
    }

    private fun findModelAsset(): String? {
        val present = try {
            context.assets.list("")?.toSet() ?: emptySet()
        } catch (_: Exception) {
            emptySet()
        }
        return MODEL_CANDIDATES.firstOrNull { it in present }
    }

    companion object {
        /** First file found in app/src/main/assets wins. */
        val MODEL_CANDIDATES = listOf(
            "efficientdet_lite0.tflite",
            "efficientdet_lite1.tflite",
            "efficientdet_lite2.tflite",
            "model.tflite"
        )
        private const val MAX_RESULTS = 50
        private const val SCORE_FLOOR = 0.2f
    }
}
