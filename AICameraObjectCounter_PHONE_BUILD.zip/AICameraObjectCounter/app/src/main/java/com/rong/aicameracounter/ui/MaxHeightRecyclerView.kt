package com.rong.aicameracounter.ui

import android.content.Context
import android.util.AttributeSet
import android.view.View
import androidx.recyclerview.widget.RecyclerView

/** RecyclerView that wraps its content up to [maxHeightDp] and scrolls beyond that. */
class MaxHeightRecyclerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : RecyclerView(context, attrs) {

    var maxHeightDp: Int = 176
        set(v) { field = v; requestLayout() }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val maxPx = (maxHeightDp * resources.displayMetrics.density).toInt()
        super.onMeasure(widthSpec, View.MeasureSpec.makeMeasureSpec(maxPx, View.MeasureSpec.AT_MOST))
    }
}
