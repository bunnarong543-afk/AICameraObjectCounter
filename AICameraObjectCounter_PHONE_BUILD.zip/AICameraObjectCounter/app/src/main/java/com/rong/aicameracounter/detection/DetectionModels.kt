package com.rong.aicameracounter.detection

import kotlin.math.max
import kotlin.math.min

/**
 * One detected object. The box is in pixels of the UPRIGHT analysis frame
 * (i.e. after the camera rotation has been applied), origin top-left.
 *
 * Deliberately free of android.* types so the counting logic can be unit-tested on the JVM.
 */
data class DetectedObject(
    val label: String,
    val score: Float,
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
) {
    val area: Float
        get() = max(0f, right - left) * max(0f, bottom - top)

    /** Intersection-over-union with another box. */
    fun iou(other: DetectedObject): Float {
        val iw = min(right, other.right) - max(left, other.left)
        val ih = min(bottom, other.bottom) - max(top, other.top)
        if (iw <= 0f || ih <= 0f) return 0f
        val inter = iw * ih
        val union = area + other.area - inter
        return if (union <= 0f) 0f else inter / union
    }
}

/** Raw output of one inference pass, before user filters are applied. */
data class FrameDetections(
    val detections: List<DetectedObject>,
    /** Width/height of the upright frame the boxes refer to. */
    val frameWidth: Int,
    val frameHeight: Int,
    val inferenceMs: Long
)
