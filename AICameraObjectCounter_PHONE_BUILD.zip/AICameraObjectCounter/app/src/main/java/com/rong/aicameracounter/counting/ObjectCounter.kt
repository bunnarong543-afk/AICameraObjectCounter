package com.rong.aicameracounter.counting

import com.rong.aicameracounter.detection.DetectedObject
import com.rong.aicameracounter.settings.AppSettings

/** Count of one category in the CURRENT frame. [visible] is false when the user hid the category. */
data class CategoryCount(val label: String, val count: Int, val visible: Boolean)

data class CountSummary(
    /** Total of the categories that are visible (not hidden by the user). */
    val total: Int,
    /** All categories seen in this frame, including hidden ones so they can be switched back on. */
    val categories: List<CategoryCount>,
    /** Detections to draw: visible categories only. */
    val visibleDetections: List<DetectedObject>
) {
    companion object {
        val EMPTY = CountSummary(0, emptyList(), emptyList())
    }
}

/**
 * Turns one frame of raw detections into the numbers shown on screen.
 *
 * It is stateless on purpose: every call looks at a single frame only, so counts never
 * accumulate across frames. (Cumulative statistics live in [SessionStats], separately.)
 *
 * Steps: confidence filter -> class-wise NMS (removes duplicate overlapping boxes the
 * model's own post-processing left behind) -> cap at the user's maximum -> group by label.
 */
class ObjectCounter(private val nmsIouThreshold: Float = 0.6f) {

    fun summarize(raw: List<DetectedObject>, settings: AppSettings): CountSummary {
        if (raw.isEmpty() || settings.maxDetections <= 0) return CountSummary.EMPTY

        val confident = raw
            .filter { it.score >= settings.confidenceThreshold }
            .sortedByDescending { it.score }
        if (confident.isEmpty()) return CountSummary.EMPTY

        val kept = suppressDuplicates(confident).take(settings.maxDetections)
        val hidden = settings.hiddenCategories

        val categories = kept
            .groupBy { it.label }
            .map { (label, items) -> CategoryCount(label, items.size, label !in hidden) }
            .sortedWith(compareByDescending<CategoryCount> { it.count }.thenBy { it.label })

        val visibleDetections = kept.filter { it.label !in hidden }
        return CountSummary(
            total = visibleDetections.size,
            categories = categories,
            visibleDetections = visibleDetections
        )
    }

    /** Greedy NMS per label. Input must be sorted by score, descending. */
    private fun suppressDuplicates(sorted: List<DetectedObject>): List<DetectedObject> {
        val result = ArrayList<DetectedObject>(sorted.size)
        for (candidate in sorted) {
            var duplicate = false
            for (existing in result) {
                if (existing.label == candidate.label && existing.iou(candidate) > nmsIouThreshold) {
                    duplicate = true
                    break
                }
            }
            if (!duplicate) result.add(candidate)
        }
        return result
    }
}
