package com.rong.aicameracounter.camera

import android.content.Context
import android.util.Size
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.util.concurrent.Executor

/**
 * Owns the CameraX use cases (preview + image analysis) and the camera state
 * (lens direction, torch). All methods must be called on the main thread.
 *
 * Preview and analysis both use a 4:3 aspect ratio, so the analysis frame covers exactly the
 * same field of view as the preview. DetectionOverlayView relies on that to map boxes.
 */
class CameraController(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val previewView: PreviewView,
    private val analysisExecutor: Executor,
    private val analyzer: ImageAnalysis.Analyzer,
    private val listener: Listener
) {

    interface Listener {
        fun onCameraReady(isFrontCamera: Boolean, hasFlash: Boolean)
        fun onCameraError(kind: ErrorKind, detail: String)
    }

    enum class ErrorKind { NO_CAMERA, START_FAILED }

    var lensFacing: Int = CameraSelector.LENS_FACING_BACK
        private set

    var torchOn: Boolean = false
        private set

    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var analysis: ImageAnalysis? = null
    private var released = false

    val isFrontCamera: Boolean get() = lensFacing == CameraSelector.LENS_FACING_FRONT

    val hasFlash: Boolean get() = camera?.cameraInfo?.hasFlashUnit() == true

    fun start() {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            if (released) return@addListener
            try {
                provider = future.get()
                bind()
            } catch (e: Exception) {
                listener.onCameraError(ErrorKind.START_FAILED, e.message ?: e.javaClass.simpleName)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun switchCamera() {
        lensFacing = if (isFrontCamera) CameraSelector.LENS_FACING_BACK else CameraSelector.LENS_FACING_FRONT
        bind()
    }

    /** Returns the new torch state, or null if this camera has no flash unit. */
    fun toggleTorch(): Boolean? {
        val cam = camera ?: return null
        if (!cam.cameraInfo.hasFlashUnit()) return null
        torchOn = !torchOn
        cam.cameraControl.enableTorch(torchOn)
        return torchOn
    }

    fun shutdown() {
        released = true
        analysis?.clearAnalyzer()
        provider?.unbindAll()
        camera = null
        analysis = null
    }

    private fun bind() {
        val p = provider ?: return
        val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
        if (!p.hasCamera(selector)) {
            // Fall back to the other lens if this device only has one.
            val other = if (isFrontCamera) CameraSelector.LENS_FACING_BACK else CameraSelector.LENS_FACING_FRONT
            val otherSelector = CameraSelector.Builder().requireLensFacing(other).build()
            if (p.hasCamera(otherSelector)) {
                lensFacing = other
                bind()
            } else {
                listener.onCameraError(ErrorKind.NO_CAMERA, "")
            }
            return
        }

        val aspect = AspectRatioStrategy(AspectRatio.RATIO_4_3, AspectRatioStrategy.FALLBACK_RULE_AUTO)
        val previewSelector = ResolutionSelector.Builder().setAspectRatioStrategy(aspect).build()
        // ~640x480 is a good speed/accuracy trade-off: the model input is only 320-512 px anyway.
        val analysisSelector = ResolutionSelector.Builder()
            .setAspectRatioStrategy(aspect)
            .setResolutionStrategy(
                ResolutionStrategy(Size(640, 480), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
            )
            .build()

        val preview = Preview.Builder().setResolutionSelector(previewSelector).build()
        preview.setSurfaceProvider(previewView.surfaceProvider)

        val imageAnalysis = ImageAnalysis.Builder()
            .setResolutionSelector(analysisSelector)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
            .build()
        imageAnalysis.setAnalyzer(analysisExecutor, analyzer)

        try {
            p.unbindAll()
            camera = p.bindToLifecycle(lifecycleOwner, selector, preview, imageAnalysis)
            analysis = imageAnalysis
            torchOn = false
            listener.onCameraReady(isFrontCamera, hasFlash)
        } catch (e: Exception) {
            listener.onCameraError(ErrorKind.START_FAILED, e.message ?: e.javaClass.simpleName)
        }
    }
}
