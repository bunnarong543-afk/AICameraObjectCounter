package com.rong.aicameracounter.counting

import com.rong.aicameracounter.detection.DetectedObject
import com.rong.aicameracounter.settings.AppSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ObjectCounterTest {

    private val counter = ObjectCounter()
    private val settings = AppSettings(confidenceThreshold = 0.5f, maxDetections = 20)

    private fun obj(label: String, score: Float, l: Float, t: Float, r: Float, b: Float) =
        DetectedObject(label, score, l, t, r, b)

    @Test
    fun emptyInputGivesEmptySummary() {
        val s = counter.summarize(emptyList(), settings)
        assertEquals(0, s.total)
        assertTrue(s.categories.isEmpty())
    }

    @Test
    fun belowThresholdIsIgnored() {
        val s = counter.summarize(listOf(obj("person", 0.3f, 0f, 0f, 10f, 10f)), settings)
        assertEquals(0, s.total)
    }

    @Test
    fun groupsByCategoryAndTotals() {
        val list = listOf(
            obj("person", 0.9f, 0f, 0f, 10f, 10f),
            obj("person", 0.8f, 100f, 0f, 110f, 10f),
            obj("car", 0.7f, 200f, 0f, 260f, 40f)
        )
        val s = counter.summarize(list, settings)
        assertEquals(3, s.total)
        assertEquals(listOf("person", "car"), s.categories.map { it.label })
        assertEquals(2, s.categories.first { it.label == "person" }.count)
    }

    @Test
    fun duplicateOverlappingBoxesOfSameLabelAreMerged() {
        val list = listOf(
            obj("person", 0.9f, 0f, 0f, 100f, 100f),
            obj("person", 0.8f, 2f, 2f, 102f, 102f)
        )
        assertEquals(1, counter.summarize(list, settings).total)
    }

    @Test
    fun overlappingBoxesOfDifferentLabelsAreKept() {
        val list = listOf(
            obj("person", 0.9f, 0f, 0f, 100f, 100f),
            obj("backpack", 0.8f, 2f, 2f, 102f, 102f)
        )
        assertEquals(2, counter.summarize(list, settings).total)
    }

    @Test
    fun maxDetectionsKeepsHighestScores() {
        val list = (0 until 5).map { obj("cup", 0.9f - it * 0.05f, it * 50f, 0f, it * 50f + 10f, 10f) }
        val s = counter.summarize(list, settings.copy(maxDetections = 3))
        assertEquals(3, s.total)
    }

    @Test
    fun hiddenCategoryIsListedButNotCounted() {
        val list = listOf(
            obj("person", 0.9f, 0f, 0f, 10f, 10f),
            obj("car", 0.9f, 100f, 0f, 160f, 40f)
        )
        val s = counter.summarize(list, settings.copy(hiddenCategories = setOf("car")))
        assertEquals(1, s.total)
        assertEquals(1, s.visibleDetections.size)
        assertEquals(2, s.categories.size)
        assertEquals(false, s.categories.first { it.label == "car" }.visible)
    }

    @Test
    fun countsDoNotAccumulateAcrossCalls() {
        val frame = listOf(obj("person", 0.9f, 0f, 0f, 10f, 10f))
        counter.summarize(frame, settings)
        assertEquals(1, counter.summarize(frame, settings).total)
    }
}
