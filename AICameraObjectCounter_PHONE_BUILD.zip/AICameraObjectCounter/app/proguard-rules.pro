# Release minification is disabled in app/build.gradle.kts.
# If you enable it, keep TensorFlow Lite's JNI-facing classes:
-keep class org.tensorflow.lite.** { *; }
-dontwarn org.tensorflow.lite.**
