plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rong.aicameracounter"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.rong.aicameracounter"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            // Minification is off on purpose: TensorFlow Lite uses JNI and reflection,
            // and this project has not been verified with R8 on a device.
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }

    // The .tflite model must stay uncompressed so TFLite can memory-map it.
    androidResources {
        noCompress += "tflite"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")

    // CameraX
    val cameraX = "1.3.4"
    implementation("androidx.camera:camera-core:$cameraX")
    implementation("androidx.camera:camera-camera2:$cameraX")
    implementation("androidx.camera:camera-lifecycle:$cameraX")
    implementation("androidx.camera:camera-view:$cameraX")

    // TensorFlow Lite Task Library (object detector, reads labels from model metadata).
    // CPU only: no GPU/NNAPI delegate is bundled because it could not be tested on a device.
    implementation("org.tensorflow:tensorflow-lite-task-vision:0.4.4")

    testImplementation("junit:junit:4.13.2")
}

// ---------------------------------------------------------------------------
// Optional helper:  ./gradlew downloadModel
// Downloads EfficientDet-Lite0 (with metadata) into app/src/main/assets.
// See MODEL_SETUP.md for the manual alternative and the alternate URL.
// ---------------------------------------------------------------------------
tasks.register("downloadModel") {
    group = "setup"
    description = "Downloads efficientdet_lite0.tflite into app/src/main/assets"
    val modelUrl =
        "https://storage.googleapis.com/download.tensorflow.org/models/tflite/task_library/" +
            "object_detection/android/lite-model_efficientdet_lite0_detection_metadata_1.tflite"
    val target = layout.projectDirectory.file("src/main/assets/efficientdet_lite0.tflite").asFile
    doLast {
        target.parentFile.mkdirs()
        val tmp = File(target.parentFile, "efficientdet_lite0.tflite.part")
        try {
            java.net.URL(modelUrl).openStream().use { input ->
                tmp.outputStream().use { output -> input.copyTo(output) }
            }
            check(tmp.length() > 100_000) {
                "Downloaded file is only ${tmp.length()} bytes - this is an error page, not a model. " +
                    "Download it manually (see MODEL_SETUP.md)."
            }
            tmp.copyTo(target, overwrite = true)
            println("Model saved to ${target.absolutePath} (${target.length()} bytes)")
        } finally {
            tmp.delete()
        }
    }
}
